package com.example.petclinic.business;

import com.example.petclinic.service.OwnerService;

import java.security.acl.Owner;

public class PetClinicBusinessWorkflow {
    OwnerService ownerService;

    public PetClinicBusinessWorkflow(OwnerService ownerService) {this.ownerService = ownerService};
    //Finish THIS?

    public void runBusiness(){

        // TODO Add business stuff here

        // create owners
        Owner owner1 = Owner.builder().withName("Homer Simpson").withAddess("742 Evergreen Terrace");
        Owner owner2 = Owner.builder().withName("Marge Simpson").withAddess("742 Evergreen Terrace");
        Owner owner3 = Owner.builder().withName("Bart Simpson").withAddess("742 Evergreen Terrace");
        Owner owner4 = Owner.builder().withName("Lisa Simpson").withAddess("742 Evergreen Terrace");

        ownerService.saveOwner(owner1);
        ownerService.saveOwner(owner2);
        ownerService.saveOwner(owner3);
        ownerService.saveOwner(owner4);
    }
}
