package com.example.petclinic;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetClinicClient {

    public static void main(String[] args) {

        ApplicationContext context = SpringApplication.run(PetClinicClient.class,args)

        PetClinicBusnessWorkFlow business = ()        //Finish

    }
}
