package com.example.petclinic.service;

import com.example.petclinic.model.Visit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;


@Service
public class VisitService {

    private static final Logger log = LoggerFactory.getLogger(VisitService.class);

    RestTemplate restTemplate;

    public VisitService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Visit saveVisit(Visit visit) {

        URI uri = URI.create("http://localhost:8084/visit/addVisit");

        Visit response = restTemplate.postForObject(uri, visit, Visit.class);
        log.info(response.toString());
        return response;
    }


}
