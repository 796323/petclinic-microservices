package com.example.petclinic.service;

import com.example.petclinic.model.Pet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@Service
public class PetService {
    private static final Logger log = LoggerFactory.getLogger(PetService.class);

    RestTemplate restTemplate;

    public PetService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // TODO This doesn't create pet (errors)
    public Pet savePet(Pet pet) {

        URI uri = URI.create("http://localhost:8082/pet/addPet");

        Pet response = restTemplate.postForObject(uri, pet, Pet.class);
        log.info(response.toString());
        return response;
    }


}
