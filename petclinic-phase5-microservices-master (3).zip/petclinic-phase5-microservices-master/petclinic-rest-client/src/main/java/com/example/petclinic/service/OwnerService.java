package com.example.petclinic.service;

import com.example.petclinic.model.Owner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@Service
public class OwnerService {

    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Owner saveOwner(Owner owner) {

        URI uri = URI.create("http://localhost:8089/owner/addOwner");

        Owner response = restTemplate.postForObject(uri, owner, Owner.class);
        log.info(response.toString());
        return response;
    }

    //TODO Unable to getAllOwners() to work properly below
    public List<Owner> getAllOwners() {

        URI uri = URI.create("http://localhost:8089/owner/getAllOwners");

        List<Owner> response = restTemplate.getForObject(uri, List.class);
        log.info(response.toString());
        return response;
    }

}
