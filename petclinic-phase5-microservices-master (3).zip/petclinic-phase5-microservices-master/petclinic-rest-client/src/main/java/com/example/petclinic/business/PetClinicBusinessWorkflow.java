package com.example.petclinic.business;

import com.example.petclinic.model.Owner;
import com.example.petclinic.model.Pet;
import com.example.petclinic.model.PetType;
import com.example.petclinic.service.OwnerService;
import com.example.petclinic.service.PetService;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;


@Component
public class PetClinicBusinessWorkflow {
    OwnerService ownerService;
    PetService petService;

    public PetClinicBusinessWorkflow(OwnerService ownerService, PetService petService) {
        this.ownerService = ownerService;
        this.petService = petService;
    }

    public void runBusiness() {

        // TODO Add business stuff here

        // create owners
        Owner owner1 = Owner.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();
        Owner owner2 = Owner.builder().withName("Marge Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();
        Owner owner3 = Owner.builder().withName("Bart Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();
        Owner owner4 = Owner.builder().withName("Lisa Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();

        ownerService.saveOwner(owner1);
        ownerService.saveOwner(owner2);
        ownerService.saveOwner(owner3);
        ownerService.saveOwner(owner4);

        //TODO This doesn't produce getAllOwners (errors)
        List<Owner> owners = ownerService.getAllOwners();

        owners.forEach(System.out::println);

        // TODO This doesn't create pet (errors)
        Pet pet1 = Pet.builder().withName("Jackie").withBirthDate(new Date()).withPetType(PetType.BIRD).build();
        petService.savePet(pet1);

    }
}
